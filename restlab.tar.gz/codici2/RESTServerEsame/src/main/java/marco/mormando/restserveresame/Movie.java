/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.restserveresame;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author marcomormando
 */
@XmlRootElement
public class Movie {
    private int id;
    private String title;
    private String year;
    private int directorID;
    private Director director;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getDirectorID() {
        return directorID;
    }

    public void setDirectorID(int directorID) {
        this.directorID = directorID;
    }

    public Director getDirector() {
        return director;
    }

    public void setDirector(Director director) {
        this.director = director;
    }
    
    @Override
    public String toString(){
        return String.format("Movie id: %d, title: %s, year: %s, directorID: %d,\nDirector id: %d, name: %s, yearOfBirth: %s\n",
                            this.id, this.title, this.year, this.directorID, this.director.getId(), this.director.getName(), this.director.getYearOfBirth());
    }
}
