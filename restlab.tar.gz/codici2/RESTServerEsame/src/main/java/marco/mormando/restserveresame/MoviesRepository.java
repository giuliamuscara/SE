/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.restserveresame;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

/**
 *
 * @author marcomormando
 */
@Path("/movies")
@Produces("text/xml")
public class MoviesRepository {
    
    private Connection conn;

    public void setConnection(String pos) {
        try {
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
            }
            conn = DriverManager.getConnection("jdbc:sqlite:"+pos);
        } catch (SQLException ex) {
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @GET
    @Path("")
    public List<Movie> getMovies() {
        return getMoviesFromDB();
    }
    
    @GET
    @Path("{movieId}")
    public Movie getCourse(@PathParam("movieId") int movieId) {
        return findById(movieId);
    }
    
    private List<Movie> getMoviesFromDB(){
        
        PreparedStatement stat = null;
        List movies = new ArrayList<Movie>();
        Movie movie = null;
        Director director = null;
        
        try {
            stat = conn.prepareStatement("select * from movies join directors on directorID = directors.id");
        
            ResultSet rs = stat.executeQuery();
            while(rs.next()){
            
                movie = new Movie();
                director = new Director();

                director.setId(rs.getInt("directorID"));
                director.setName(rs.getString("name"));
                director.setYearOfBirth(rs.getString("yearOfBirth"));

                movie.setId(rs.getInt("id"));
                movie.setTitle(rs.getString("title"));
                movie.setYear(rs.getString("year"));
                movie.setDirectorID(rs.getInt("directorID"));
                movie.setDirector(director);

                movies.add(movie);

                Logger.getLogger(MoviesRepository.class.getName()).log(Level.INFO, "Accessed Movie: \n" + movie);
//              rs.close();
            }   
        } catch (SQLException ex) {
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return movies;           
    }
    
    private Movie findById(int movieId){
        
        PreparedStatement stat = null;
        Movie movie = null;
        Director director = null;
        
        try {
            stat = conn.prepareStatement("select * from movies join directors on directorID = directors.id where movies.id = ?");
            stat.setInt(1, movieId);
        
            ResultSet rs = stat.executeQuery();
            if (rs.next()) {

                movie = new Movie();
                director = new Director();

                director.setId(rs.getInt("directorID"));
                director.setName(rs.getString("name"));
                director.setYearOfBirth(rs.getString("yearOfBirth"));

                movie.setId(rs.getInt("id"));
                movie.setTitle(rs.getString("title"));
                movie.setYear(rs.getString("year"));
                movie.setDirectorID(rs.getInt("directorID"));
                movie.setDirector(director);

                Logger.getLogger(MoviesRepository.class.getName()).log(Level.INFO, "Accessed Movie: \n" + movie);
                //        rs.close();

            }
        } catch (SQLException ex) {
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
        return movie;   
    }
}
