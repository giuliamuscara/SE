/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.databasemanageresame;
import java.sql.*;


/**
 *
 * @author marcomormando
 */
public class DatabaseManager {
    public static void main(String[] args) throws Exception{
        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:" + args[0]);
        Statement stat = conn.createStatement();
        
        if(args[1].equals("create")){
            stat.executeUpdate("drop table if exists movies;");
            stat.executeUpdate("drop table if exists directors;");
            stat.executeUpdate("create table movies (id, title, year, directorID);");
            stat.executeUpdate("create table directors (id, name, yearOfBirth);");
            
            PreparedStatement prep = conn.prepareStatement("insert into directors values (?, ?, ?);");
            
            prep.setInt(1, 1);
            prep.setString(2, "Marco Mormando");
            prep.setString(3, "1997");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 2);
            prep.setString(2, "Antonio Mormando");
            prep.setString(3, "1954");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 3);
            prep.setString(2, "Carlo Cracco");
            prep.setString(3, "2000");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 4);
            prep.setString(2, "Giacomo Folli");
            prep.setString(3, "1890");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep = conn.prepareStatement("insert into movies values (?, ?, ?, ?);");
            
            prep.setInt(1, 1);
            prep.setString(2, "Film 1");
            prep.setString(3, "1920");
            prep.setInt(4, 1);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 2);
            prep.setString(2, "Film 2");
            prep.setString(3, "1957");
            prep.setInt(4, 3);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 3);
            prep.setString(2, "Film 3");
            prep.setString(3, "1930");
            prep.setInt(4, 3);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 4);
            prep.setString(2, "Film 4");
            prep.setString(3, "1909");
            prep.setInt(4, 4);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 5);
            prep.setString(2, "Film 5");
            prep.setString(3, "2100");
            prep.setInt(4, 4);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 6);
            prep.setString(2, "Film 6");
            prep.setString(3, "2010");
            prep.setInt(4, 2);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 7);
            prep.setString(2, "Film 7");
            prep.setString(3, "1879");
            prep.setInt(4, 1);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 8);
            prep.setString(2, "Film 8");
            prep.setString(3, "2006");
            prep.setInt(4, 1);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 9);
            prep.setString(2, "Film 9");
            prep.setString(3, "2001");
            prep.setInt(4, 1);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 10);
            prep.setString(2, "Film 10");
            prep.setString(3, "1997");
            prep.setInt(4, 2);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 11);
            prep.setString(2, "Film 11");
            prep.setString(3, "1998");
            prep.setInt(4, 4);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 12);
            prep.setString(2, "Film 12");
            prep.setString(3, "1999");
            prep.setInt(4, 2);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 13);
            prep.setString(2, "Film 13");
            prep.setString(3, "2020");
            prep.setInt(4, 1);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 14);
            prep.setString(2, "Film 14");
            prep.setString(3, "1980");
            prep.setInt(4, 3);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 15);
            prep.setString(2, "Film 15");
            prep.setString(3, "1900");
            prep.setInt(4, 2);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setInt(1, 16);
            prep.setString(2, "Film 16");
            prep.setString(3, "1901");
            prep.setInt(4, 1);
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
        }
        else if(args[1].equals("read")){
            ResultSet rs = stat.executeQuery("select * from movies join directors on directorID = directors.id");
            while(rs.next()){
                System.out.println(String.format(""
                        + "Movie id: %d, title: %s, year: %s, directorID: %d,\nDirector id: %d, name: %s, yearOfBirth: %s\n",
                        rs.getInt("id"), rs.getString("title"), rs.getString("year"), rs.getInt("directorID"),
                        rs.getInt("directorID"), rs.getString("name"), rs.getString("yearOfBirth")
                ));
            }
            rs.close();
        }
        else{
            System.out.println("Comando non riconosciuto.");
        }
        conn.close();
    }
}
