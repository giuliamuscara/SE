/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.db.october.exam;

/**
 *
 * @author studente
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBSetup {
     public static void main(String[] args) throws Exception {

        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:/home/studente/Desktop/public/database");

        // manage session results
        if (conn != null) {
            System.out.println("Connected!");
        } else {
            System.out.println("Failed to make connection!");
        }

        Statement s = conn.createStatement();



            //drop table if exists
            s.executeUpdate("drop table if exists seller;");
            s.executeUpdate("drop table if exists books;");

            //Create tables
            String tableAuthors = "CREATE TABLE seller("
                    + "id INT PRIMARY KEY ,"
                    + "name TEXT,"
                    + "yeardelivery TEXT,"
                    + "idbook INT ,"
                    + "FOREIGN KEY (idbook) REFERENCES books(id)"
                    + ");";

            String tableBooks = "CREATE TABLE books("
                    + "id INT PRIMARY KEY,"
                    + "title TEXT,"
                    + "year TEXT,"
                    + "author TEXT,"
                    + "price REAL"
                    + ");";

            s.executeUpdate(tableAuthors);
            s.executeUpdate(tableBooks);

            //Populate Tables
            s.executeUpdate("insert into seller values(1, 'Seller1', '1976',1);");
            s.executeUpdate("insert into seller values(2, 'Seller1', '1976',2);");
            s.executeUpdate("insert into seller values(3, 'Seller1', '1976',3);");
            s.executeUpdate("insert into seller values(4, 'Seller2', '1976',3);");
            s.executeUpdate("insert into seller values(5, 'Seller2', '1976',4);");
            s.executeUpdate("insert into seller values(6, 'Seller3', '1976',5);");

            s.executeUpdate("insert into books values(1, 'book1', '2007','A',1.5);");
            s.executeUpdate("insert into books values(2, 'book2', '2006','B',1.5);");
            s.executeUpdate("insert into books values(3, 'book3', '2018','C',1.5);");
            s.executeUpdate("insert into books values(4, 'book4', '2010','D',1.5);");
            s.executeUpdate("insert into books values(5, 'book5', '2005','E',1.5);");
            s.executeUpdate("insert into books values(6, 'book6', '2008','F',1.5);");
            s.executeUpdate("insert into books values(7, 'book7', '2019','G',1.5);");
            s.executeUpdate("insert into books values(8, 'book8', '1999','H',1.5);");
            s.executeUpdate("insert into books values(9, 'book9', '2002','I',1.5);");
            s.executeUpdate("insert into books values(10, 'book10', '2018','L',1.5);");
            s.executeUpdate("insert into books values(11, 'book11', '2017','M',1.5);");
            s.executeUpdate("insert into books values(12, 'book12', '2011','N',1.5);");
            s.executeUpdate("insert into books values(13, 'book13', '2013','O',1.5);");
            s.executeUpdate("insert into books values(14, 'book14', '2000','p',1.5);");
            s.executeUpdate("insert into books values(15, 'book15', '2009','Q',1.5);");
        conn.close();
          
        }
        
    }
    

