/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.october.exam.client;

/**
 *
 * @author studente
 */
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import javax.xml.bind.JAXB;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import java.util.*;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import soap.*;
import java.util.List;
import java.util.Map;
public class Client {
    private static final String BASE_URL = "http://localhost:8080/";
    private static CloseableHttpClient client;

    public static void main(String[] args) throws IOException{
        Book b = new Book();
        int i = 2;
        b = getBook(i);
        System.out.println("Libro :" + i + " con titolo "+ b.getTitle() +" con autore "+ b.getAuthor() + " con data di publicazione " + b.getYear1());
        
        
    soap.Book b1 = new soap.Book();
    //b1 = getProfessor(1);
    List<soap.Date> Sl = new ArrayList();
    Sl = b1.getSeller();
    //System.out.println(b1.getPrice());
    //for(soap.Date a : Sl){
    //    System.out.println("Name Seller: " + a.getName()+ " with delivery of the book:" + a.getDate());
    
   // }
    
    }
    
    private static Book getBooks() throws IOException {
        final URL url = new URL(BASE_URL  + "books/allbooks");
        final InputStream input = url.openStream();
        return JAXB.unmarshal(new InputStreamReader(input), Book.class );
    }
    
    private static Book getBook(int id) throws IOException {
        final URL url = new URL(BASE_URL  + "/books/"+id);
        final InputStream input = url.openStream();
        return JAXB.unmarshal(new InputStreamReader(input), Book.class );
    }
    
    private static soap.Book getProfessor(Integer arg0) {
        soap.WSImplService service = new soap.WSImplService();
        soap.WSInterface port = service.getWSImplPort();
        return port.getProfessor(arg0);
    }
}
