/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.soap.exam.october;

import java.util.List;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author studente
 */
@XmlType(name = "Book")
public class BookImpl implements Book{
    private Float price;
    private List<Seller> seller;
    public Float getPrice() { return price; }
    public List<Seller> getSeller() { return seller; }
    public void setPrice(Float n) { price = n; }
    public void setSeller(List<Seller> n) { seller = n; }
    public BookImpl(Float n, List<Seller> m) { price = n; seller = m; } 
    public BookImpl() {}
}
