/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.soap.exam.october;
//List<Book> books = new ArrayList<>();
/**
 *
 * @author studente
 */
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.*;
@XmlJavaTypeAdapter(BookAdapter.class)
public interface Book {
    public Float getPrice();
    public List<Seller> getSeller();
    public void setPrice(Float m);
    public void setSeller(List<Seller> n );

}
