/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.soap.exam.october;

/**
 *
 * @author studente
 */

import java.sql.*;
/**
 *
 * @author studente
 */
import javax.jws.WebService;
import java.util.*;
@WebService(endpointInterface = "it.sapienza.soap.exam.october.WSInterface")
public class WSImpl implements WSInterface {
    public Book getProfessor(Integer id){
    return findby(id);
    }
    public Book findby(Integer id){
        Connection conn;
        List<Seller> all = new ArrayList<>();
        PreparedStatement stat = null;
        PreparedStatement stat1 = null;
        Book prof = null;
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException ex) {
                System.out.println("driver non trovato");
            }
        try {
            conn= DriverManager.getConnection("jdbc:sqlite:/home/studente/Desktop/public/database");
            stat = conn.prepareStatement("select * from book where id = ?");
            stat.setString(1, String.valueOf(id));
        
        ResultSet rs = stat.executeQuery();
         if (rs.next()) {
         prof = new BookImpl();
         prof.setPrice(rs.getFloat("price"));
         stat1 = conn.prepareStatement("select * from seller where idbook = ?");
         stat.setString(1, String.valueOf(id));
         ResultSet rs1 = stat.executeQuery();
         while(rs1.next()){
         Seller sl = new Seller();
         sl.setDate(rs1.getString("yeardelivery"));
         sl.setName(rs1.getString("name"));
         all.add(sl);
         }
         prof.setSeller(all);
         rs.close();
         
         }
         else {
         System.out.println("No professors is finded");
 
         }
        }
        catch (SQLException ex) {
            System.out.println("Professore non trovato");
        }
         
        
        return prof; 
    }
}
