/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.soap.exam.october;

/**
 *
 * @author studente
 */
import javax.xml.bind.annotation.adapters.XmlAdapter;
public class BookAdapter extends XmlAdapter<BookImpl,Book>{
   public BookImpl marshal(Book prof) throws Exception {
        if (prof instanceof BookImpl)
            return (BookImpl) prof;
        return new BookImpl(prof.getPrice(), prof.getSeller());
    }

    @Override
    public Book unmarshal(BookImpl v) throws Exception {
        return v;
    } 
}
