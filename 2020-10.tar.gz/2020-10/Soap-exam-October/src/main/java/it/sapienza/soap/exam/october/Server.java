package it.sapienza.soap.exam.october;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author studente
 */
import javax.xml.ws.Endpoint;
public class Server {
    public static void main(String args[]) throws InterruptedException, Exception {
        WSImpl implementor = new WSImpl();
        String address = "http://127.0.0.1:9999/WSInterface";
        Endpoint.publish(address, implementor);
        while (true){
        
        }
        
    }
    
}
