/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.soap.exam.october;
import javax.xml.bind.annotation.XmlType;
/**
 *
 * @author studente
 */
@XmlType(name = "Date")
public class Seller {
    private String name;
    private String date;
    public String getName() { return name; }
    public String getDate() { return date; }
    public void setName(String n) { name = n; }
    public void setDate(String n) { date = n; }
    public Seller(String n, String m) { name = n; date = m; } 
    public Seller() {}
}
