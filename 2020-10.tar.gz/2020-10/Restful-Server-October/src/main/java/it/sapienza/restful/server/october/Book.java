/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.restful.server.october;

/**
 *
 * @author studente
 */

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;

@XmlRootElement(name = "Book")
public class Book {
    private int id;
    private String title;
    private String author;
    private String yearofPublication;

      public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
      
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    
        public String getAuthor() {
        return author;
    }

    public void setAuthor(String title) {
        this.author = title;
    }
    
    
        public String getYear1() {
        return yearofPublication;
    }

    public void setYear1(String year) {
        this.yearofPublication = year;
    }
            
    @Override
    public int hashCode() {
        return id + title.hashCode()+ yearofPublication.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return (obj instanceof Book) && (id == ((Book) obj).getId()) && (title.equals(((Book) obj).getTitle()))&& (yearofPublication.equals(((Book) obj).getYear1()));
    }
    
}
