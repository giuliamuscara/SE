/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.sapienza.restful.server.october;

/**
 *
 * @author studente
 */
import javax.ws.rs.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;

@Path("/books")
@Produces("text/xml")
public class BookRepository {
    private Connection conn;

     {
        try {
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(BookRepository.class.getName()).log(Level.SEVERE, "hi", ex);
            }
            conn
                    = DriverManager.getConnection("jdbc:sqlite:/home/studente/Desktop/public/database");
            System.out.println("Hello world");
        } catch (SQLException ex) {
            Logger.getLogger(BookRepository.class.getName()).log(Level.SEVERE, "hello", ex);
        }
    }
     
    @GET
    @Path("/allbooks")
    public List<Book> getCourse1() {
        return getAllBooks();
    }

    private List<Book> getAllBooks(){
        PreparedStatement stat = null;
        
        List<Book> books = new ArrayList<>();
      try {
          //conn= DriverManager.getConnection("jdbc:sqlite:/home/studente/database");
           stat = conn.prepareStatement("select * from books");

            ResultSet bookRs = stat.executeQuery();

            while (bookRs.next()) {
                
                try {
                    Book book = new Book();

                    book.setId(Integer.parseInt(bookRs.getString("id")));
                    book.setTitle(bookRs.getString("title"));
                    book.setYear1(bookRs.getString("year"));
                    book.setAuthor(bookRs.getString("author"));
                    books.add(book);
                    }
                catch (SQLException ex) {
            Logger.getLogger(BookRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
                

           

    


            

                 }
        
           bookRs.close();
         
    }
      catch (SQLException ex) {
            Logger.getLogger(BookRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
    return books;   
}
   @GET
    @Path("{bookId}")
    public Book getCourse(@PathParam("bookId") int bookId) {
        return findById(bookId);
    }
    
    private Book findById(int bookId){
        PreparedStatement stat = null;
        Book book = new Book();
        
        try {
          //conn= DriverManager.getConnection("jdbc:sqlite:/home/studente/database");
           stat = conn.prepareStatement("select * from books where id = ? ;");
           stat.setString(1, String.valueOf(bookId));
           ResultSet bookRs = stat.executeQuery();

            while (bookRs.next()) {
                
                try {
                    book.setId(Integer.parseInt(bookRs.getString("id")));
                    book.setTitle(bookRs.getString("title"));
                    book.setYear1(bookRs.getString("year"));
                    book.setAuthor(bookRs.getString("author"));

                    }
                   
                catch (SQLException ex) {
            Logger.getLogger(BookRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
                
                

           

    


            

                 }
        
           bookRs.close();
         
    }
      catch (SQLException ex) {
            Logger.getLogger(BookRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
        return book;
    }  
    
}
