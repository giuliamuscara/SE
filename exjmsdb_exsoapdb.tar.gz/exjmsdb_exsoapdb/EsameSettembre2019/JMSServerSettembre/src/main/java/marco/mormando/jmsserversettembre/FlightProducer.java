/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.jmsserversettembre;

import java.util.Properties;
import java.util.Random;
import javax.jms.*;
import javax.naming.*;

/**
 *
 * @author marcomormando
 */
public class FlightProducer {

    public FlightProducer() {}
    
    public boolean creaStatus(){
        Random randomGen = new Random();
        return randomGen.nextBoolean();
    }
    
    public void start() throws NamingException, JMSException {
        Context jndiContext = null;
        ConnectionFactory connectionFactory = null;
        Connection connection = null;
        Session session = null;
        Destination destination = null;
        MessageProducer producer = null;
        String destinationName = "dynamicTopics/Flights";
        
        try{
            Properties props = new Properties();
            props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.activemq.jndi.ActiveMQInitialContextFactory");
            props.setProperty(Context.PROVIDER_URL, "tcp://localhost:61616");
            jndiContext = new InitialContext(props);
        }catch(NamingException e){
            System.out.println("Naming exception 1! Exiting...");
            System.exit(1);
        }
        
        try{
            connectionFactory = (ConnectionFactory) jndiContext.lookup("ConnectionFactory");
            destination = (Destination) jndiContext.lookup(destinationName);
        }catch(NamingException e){
            System.out.println("Naming exception 2! Exiting...");
            System.exit(1);
        }
        
        try{
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            producer = session.createProducer(destination);
            TextMessage message = null;
            String flightId = null;
            message = session.createTextMessage();
            boolean landed;
            int i = 0;
            while(true){
                i++;
                flightId = "XX" + String.valueOf(i);
                landed = creaStatus();
                message.setStringProperty("flight", flightId);
                message.setText(String.format("Item %d >> flight %s has landed : %s", i, flightId, landed));
                System.out.println(String.format("JMS Server sta pubblicando message (id: %s, flightId: %s, landed: %s)", i, flightId, landed));
                producer.send(message);
                try{
                    Thread.sleep(3500);
                } catch(Exception ex){
                    ex.printStackTrace();
                }
            }
        } catch(JMSException e){
            System.out.println("JMS Exception closing connection!");
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (JMSException ex) {
                    System.out.println("Non se puede così però");
                }
            }
        }
    }
}
