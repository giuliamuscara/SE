/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.jmsclientsettembrewithdb;

import javax.jms.JMSException;
import javax.naming.NamingException;

/**
 *
 * @author marcomormando
 */
public class ClientMain {
    public static void main(String[] args) throws JMSException, NamingException{
        new FlightsListener().start();
    }
}
