/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.soapserverluglio;
import java.util.List;
import javax.jws.WebService;
/**
 *
 * @author marcomormando
 */

@WebService(endpointInterface = "marco.mormando.soapserverluglio.WSInterface")
public class WSImpl implements WSInterface{
    
    private MoviesRepository movierep = new MoviesRepository();
    
    public WSImpl(String pos){
        movierep.setConnection(pos);
    }
    
    public String getDetailOfAMovie(int idMovie){
        return movierep.getDetailOfAMovie(idMovie);
    }
    
    public List<Movie> getMovies(){
        return movierep.getMovies();
    }
    
}
