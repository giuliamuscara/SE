/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soapclientluglio;
import java.util.List;
import marco.mormando.soapserverluglio.*;

/**
 *
 * @author marcomormando
 */
public class Client {
    public static void main(String[] args){
        System.out.println("Richiedo tutti i movies presenti nel db....");
        List<Movie> movies = Client.getMovies();
        
        for(Movie movie:movies){
            System.out.println(String.format("Movie id: %s, title: %s, year: %s, directorID: %s,\nDirector id: %s, name: %s, yearOfBirth: %s\n",
            movie.getID(), movie.getTitle(), movie.getYear(), movie.getDirectorID(), movie.getDirector().getId(), movie.getDirector().getName(), movie.getDirector().getYearOfBirth()));
        }
        
        System.out.println("Richiedo movie con id 1....");
        System.out.println(Client.getDetailOfAMovie(1));
        
        System.out.println("Richiedo movie con id 4....");
        System.out.println(Client.getDetailOfAMovie(4));
        
    }

    private static String getDetailOfAMovie(int arg0) {
        marco.mormando.soapserverluglio.WSImplService service = new marco.mormando.soapserverluglio.WSImplService();
        marco.mormando.soapserverluglio.WSInterface port = service.getWSImplPort();
        return port.getDetailOfAMovie(arg0);
    }

    private static java.util.List<marco.mormando.soapserverluglio.Movie> getMovies() {
        marco.mormando.soapserverluglio.WSImplService service = new marco.mormando.soapserverluglio.WSImplService();
        marco.mormando.soapserverluglio.WSInterface port = service.getWSImplPort();
        return port.getMovies();
    }

    

}
