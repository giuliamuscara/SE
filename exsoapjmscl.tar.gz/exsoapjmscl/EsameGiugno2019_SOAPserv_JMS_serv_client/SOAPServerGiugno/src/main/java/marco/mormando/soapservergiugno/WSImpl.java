/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.soapservergiugno;

import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;

/**
 *
 * @author marcomormando
 */
@WebService(endpointInterface = "marco.mormando.soapservergiugno.WSInterface")
public class WSImpl implements WSInterface{
    
    public final List<Professor> professors = new ArrayList<>();
    {
        Professor p;
        p = new Professor("Massimo", "Mecella");
        professors.add(p);
        p = new Professor("Giuseppe", "De Giacomo");
        professors.add(p);
        p = new Professor("Roberto", "Baldoni");
        professors.add(p);
        p = new Professor("Riccardo", "Rosati");
        professors.add(p);
        p = new Professor("Giuseppe", "Santucci");
        professors.add(p);
        p = new Professor("Maurizio", "Lenzerini");
        professors.add(p);
    }
    
    @Override
    public Professor getDetails(String id){
        int parsedID = -1;
        try{
            parsedID = Integer.parseInt(id);
        }catch(NumberFormatException ex){
            System.out.println("Number Format Exception -> retry!");
            return null;
        }
        return professors.get(parsedID);
    }
}
