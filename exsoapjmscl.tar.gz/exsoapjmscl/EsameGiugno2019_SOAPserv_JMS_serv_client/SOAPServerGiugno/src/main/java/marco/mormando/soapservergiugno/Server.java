/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.soapservergiugno;

import javax.xml.ws.Endpoint;

/**
 *
 * @author marcomormando
 */
public class Server {
    public static void main(String args[]) throws InterruptedException {
        WSImpl implementor = new WSImpl();
        for(Professor p:implementor.professors){
            System.out.println(p.getName() + " " + p.getSurname());
        }
        String address = "http://0.0.0.0:7777/WSInterface";
        Endpoint.publish(address, implementor);
        while(true) {}
    }
}
