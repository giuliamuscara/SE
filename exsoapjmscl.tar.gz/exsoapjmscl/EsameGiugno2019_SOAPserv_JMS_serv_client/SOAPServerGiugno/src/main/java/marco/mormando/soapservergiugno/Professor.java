/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.soapservergiugno;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author marcomormando
 */
@XmlRootElement
public class Professor {
    private String name;
    private String surname;

    public Professor() {}
    
    public Professor(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }
    
    
}
