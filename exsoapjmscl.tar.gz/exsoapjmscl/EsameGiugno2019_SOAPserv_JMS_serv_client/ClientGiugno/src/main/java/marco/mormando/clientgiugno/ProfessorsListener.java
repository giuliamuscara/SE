/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.clientgiugno;

import java.util.Properties;
import javax.jms.*;
import javax.naming.*;
import marco.mormando.soapservergiugno.*;

/**
 *
 * @author marcomormando
 */
public class ProfessorsListener  implements MessageListener{
    
    private TopicConnection topicConnection;
    private TopicSession topicSession;
    private Destination destination;
    
    public ProfessorsListener(){
        
        Context jndiContext = null;
        ConnectionFactory topicConnectionFactory = null;
        String destinationName = "dynamicTopics/professors";
        
        try{
            Properties props = new Properties();
            props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.activemq.jndi.ActiveMQInitialContextFactory");
            props.setProperty(Context.PROVIDER_URL, "tcp://localhost:61616");
            jndiContext = new InitialContext(props);
            topicConnectionFactory = (ConnectionFactory) jndiContext.lookup("ConnectionFactory");
            destination = (Destination) jndiContext.lookup(destinationName);
            topicConnection = (TopicConnection) topicConnectionFactory.createConnection();
            topicSession = (TopicSession) topicConnection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
            TopicSubscriber topicSubscriber = topicSession.createSubscriber((Topic)destination);
            topicSubscriber.setMessageListener(this);
        }catch(NamingException e){
            System.out.println("Naming exception! Exiting...");
            System.exit(1);
        }catch(JMSException e){
            System.out.println("JMS exception! Exiting...");
            System.exit(1);
        }
    }
    
    public void start(){
        try{
            topicConnection.start();
        }catch(JMSException ex){
            ex.printStackTrace();
        }
    }
    
    public void onMessage(Message m){
        try{
            String id = m.getStringProperty("id");
            float ranking = m.getFloatProperty("ranking");
            Professor p = null;
            
            try { // Call Web Service Operation
                WSImplService service = new WSImplService();
                WSInterface port = service.getWSImplPort();
                // TODO initialize WS operation arguments here
                String arg0 = id;
                // TODO process result here
                p = port.getDetails(arg0);
            } catch (Exception ex) {
                // TODO handle custom exceptions here
                System.out.println("Errore nella ricezione del professore!");
            }
            
            if(p != null){
                String formatted = String.format("Ricevuto id : %s con ranking %f ... bravo %s %s", id, ranking, p.getName(), p.getSurname());
                System.out.println(formatted);
            }
            
        }catch(JMSException ex){
            ex.printStackTrace();
        }
    }
    
        
    
    



    

}
