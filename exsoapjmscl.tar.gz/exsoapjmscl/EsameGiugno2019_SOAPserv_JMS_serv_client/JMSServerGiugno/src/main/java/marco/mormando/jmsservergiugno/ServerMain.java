/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.jmsservergiugno;

import java.net.InetSocketAddress;
import java.net.Socket;
import javax.jms.JMSException;
import javax.naming.NamingException;

/**
 *
 * @author marcomormando
 */
public class ServerMain {
    
    public static void main(String[] args) throws NamingException, JMSException{
        
        boolean serverReady = false;
        while(!serverReady){
            Socket sock = new Socket();
            try{
                sock.connect(new InetSocketAddress("broker", 8161), 5000);
                sock.close();
                serverReady = true;
                System.out.println("... Server now is ready ...");
            }catch(Exception ex){
                serverReady = false;
                System.out.println("... Server still is not ready ...");
            }
            
        }
        ProduttoreRanking p = new ProduttoreRanking();
        p.start();
    }
}
