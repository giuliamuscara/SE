/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package marco.mormando.jmsservergiugno;

import java.util.Properties;
import java.util.Random;
import javax.jms.*;
import javax.naming.*;

/**
 *
 * @author marcomormando
 */
public class ProduttoreRanking {
    
    private String produciId(){
        Random randomGen = new Random();
        return String.valueOf(randomGen.nextInt(6));
    }
    
    private float produciRanking(){
        Random randomGen = new Random();
        return randomGen.nextFloat() * 100;
    }
    
    public void start() throws NamingException, JMSException {
        Context jndiContext = null;
        ConnectionFactory connectionFactory = null;
        Connection connection = null;
        Session session = null;
        Destination destination = null;
        MessageProducer producer = null;
        String destinationName = "dynamicTopics/professors";
        
        try{
            Properties props = new Properties();
            props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.activemq.jndi.ActiveMQInitialContextFactory");
            props.setProperty(Context.PROVIDER_URL, "tcp://broker:61616");
            jndiContext = new InitialContext(props);
        }catch(NamingException e){
            System.out.println("Naming exception 1! Exiting...");
            System.exit(1);
        }
        
        try{
            connectionFactory = (ConnectionFactory) jndiContext.lookup("ConnectionFactory");
            destination = (Destination) jndiContext.lookup(destinationName);
        }catch(NamingException e){
            System.out.println("Naming exception 2! Exiting...");
            System.exit(1);
        }
        
        try{
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            producer = session.createProducer(destination);
            TextMessage message = null;
            String id = null;
            message = session.createTextMessage();
            float ranking;
            int i = 0;
            while(true){
                i++;
                id = produciId();
                ranking = produciRanking();
                message.setStringProperty("id", id);
                message.setFloatProperty("ranking", ranking);
                System.out.println(String.format("JMS Server sta pubblicando message (id: %s, float: %f)", id, ranking));
                producer.send(message);
                try{
                    Thread.sleep(3500);
                } catch(Exception ex){
                    ex.printStackTrace();
                }
            }
        } catch(JMSException e){
            System.out.println("JMS Exception closing connection!");
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (JMSException ex) {
                    System.out.println("Non se puede così però");
                }
            }
        }
    }
}
