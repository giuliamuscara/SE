
import java.util.List;
import marco.mormando.soapwebservice.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author marcomormando
 */
//NO POM!!!
public class Main {
    
    public static void main(String[] args){
        Student s1 = new Student();
        s1.setName("Massimo");
        helloStudent(s1);
        
        Student s2 = new Student();
        s2.setName("Monica");
        helloStudent(s2);
        
        List<StudentEntry> result = getStudents().getEntry();
        for (int i = 0 ; i<result.size(); i++){
            System.out.println(((StudentEntry)result.get(i)).getStudent().getName());
        }
    }

    //TRASCINATE DALLE REFERENCE AUTOMATICHE
    //TASTO DX CREATE NEW WEB CLIENT E POI DARE INDIRIZZO FILE WSDL!
    private static StudentMap getStudents() {
        marco.mormando.soapwebservice.WSImplService service = new marco.mormando.soapwebservice.WSImplService();
        marco.mormando.soapwebservice.WSInterface port = service.getWSImplPort();
        return port.getStudents();
    }
    
    private static String helloStudent(Student arg0) {
        marco.mormando.soapwebservice.WSImplService service = new marco.mormando.soapwebservice.WSImplService();
        marco.mormando.soapwebservice.WSInterface port = service.getWSImplPort();
        return port.helloStudent(arg0);
    }

}
