package marco.mormando.jmsclient;

import marco.mormando.jmsclient.gui.AzioniFrame;

public class StockMarketClient {
	public static void main(String[] args) {
		new AzioniFrame();
	}
}