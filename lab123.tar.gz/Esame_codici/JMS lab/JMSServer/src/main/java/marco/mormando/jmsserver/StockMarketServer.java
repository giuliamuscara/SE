package marco.mormando.jmsserver;

import org.apache.log4j.BasicConfigurator;

public class StockMarketServer {

	public static void main(String args[]) throws Exception {

            //for logger
            BasicConfigurator.configure();
            
            NotificatoreAcquisto n = new NotificatoreAcquisto();
            n.start();	

            ProduttoreQuotazioni q = new ProduttoreQuotazioni();
            q.start();
                
	}
}