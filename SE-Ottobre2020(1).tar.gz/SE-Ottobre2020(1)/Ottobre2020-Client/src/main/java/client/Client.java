package client;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import javax.xml.bind.JAXB;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class Client {
    
    private static final String BASE_URL = "http://localhost:8080/books/";
    private static CloseableHttpClient client;

    public static void main(String[] args) throws IOException{
        client = HttpClients.createDefault();
        
        System.out.println("Getting all books using REST");
        Books books = getAllBooks();
        for (int i = 0; i < books.getBooks().size(); i++) {
            Book b = books.getBooks().get(i);
            System.out.println(b);
        }
        
        System.out.println("Getting one book by id using REST");
        Book b1 = getBook(1);
        System.out.println(b1);
        
        System.out.println("Getting all books' details by id using SOAP");
        for (int i = 0; i < books.getBooks().size(); i++) {
            Book b = books.getBooks().get(i);
            System.out.println(b + " " + getBookDetails(b.getId()));
        }
        client.close();
    }

    private static Book getBook(int bookId) throws IOException {
      final URL url = new URL(BASE_URL+String.valueOf(bookId));
      final InputStream input = url.openStream();
      return JAXB.unmarshal(new InputStreamReader(input), Book.class);
    }

    private static Books getAllBooks() throws IOException {
      final URL url = new URL(BASE_URL);
      final InputStream input = url.openStream();
      return JAXB.unmarshal(new InputStreamReader(input), Books.class);
    }
    
    private static String getBookDetails(int bookId){
        soap.server.WSImplService service = new soap.server.WSImplService();
        soap.server.WSInterface port = service.getWSImplPort();
        String result = port.getBookDetails(bookId);
        return result;
    }
}
