package rest.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;


@Path("/books")
@Produces("text/xml")
public class BooksRepository {
    
    private Connection conn;
    
    public void setConnection(String pos) {
        try {
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(BooksRepository.class.getName()).log(Level.SEVERE, null, ex);
            }
            conn
                    = DriverManager.getConnection("jdbc:sqlite:"+pos);
        } catch (SQLException ex) {
            Logger.getLogger(BooksRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @GET
    @Path("{bookId}")
    public Book getBook(@PathParam("bookId") int bookId) {
        return findById(bookId);
    }
    
    @GET
    @Path("")
    public Books getAllBooks(){
        return findAllBooks();
    }
    
    private Book findById(int bookId){
        PreparedStatement stat = null;
        Book b = null;
        try {
            stat = conn.prepareStatement("select * from books where books.id = ?");
            stat.setString(1, String.valueOf(bookId));
        
        ResultSet rs = stat.executeQuery();
        if (rs.next()) {
            b = new Book();
            b.setId(Integer.parseInt(rs.getString("id")));
            b.setTitle(rs.getString("title"));
            b.setYear(rs.getString("year"));
            b.setAuthor(rs.getString("author"));
            
            Logger.getLogger(BooksRepository.class.getName()).log(Level.INFO, "Accessed : " + b);
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(BooksRepository.class.getName()).log(Level.SEVERE, null, ex);
        }

        return b;
    }
    
    private Books findAllBooks(){
        PreparedStatement stat = null;
        //creo classe Movies con dentro la lista di tutti i movies
        Books bs = new Books();
        //creo la lista vuota e la assegno
        List<Book> allBooks = new ArrayList<Book>();
        bs.setBooks(allBooks);
        Book b = null;
        try {
            stat = conn.prepareStatement("select * from books");
        
        ResultSet rs = stat.executeQuery();
        while (rs.next()) {
            b = new Book();
            b.setId(Integer.parseInt(rs.getString("id")));
            b.setTitle(rs.getString("title"));
            b.setYear(rs.getString("year"));
            b.setAuthor(rs.getString("author"));
            
            //aggiungo ogni movie alla lista dei movies
            bs.getBooks().add(b);
            
            Logger.getLogger(BooksRepository.class.getName()).log(Level.INFO, "Accessed : " + b);
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(BooksRepository.class.getName()).log(Level.SEVERE, null, ex);
        }

        return bs;
    }
}
