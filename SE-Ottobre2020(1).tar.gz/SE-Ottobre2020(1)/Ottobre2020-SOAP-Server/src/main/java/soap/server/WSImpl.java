package soap.server;

import java.util.HashMap;
import java.util.Map;
import javax.jws.WebService;

@WebService(endpointInterface = "soap.server.WSInterface")
public class WSImpl implements WSInterface{
    
    private Map<Integer, Book> books = new HashMap<Integer, Book>();
    
    public WSImpl(){
        float p1 = (float) 6.95;
        float p2 = (float) 7.95;
        float p3 = (float) 8.95;
        float p4 = (float) 9.95;
        float p5 = (float) 10.95;
        
        Map<String, String> map1 = new HashMap<String, String>();
        Map<String, String> map2 = new HashMap<String, String>();
        Map<String, String> map3 = new HashMap<String, String>();
        Map<String, String> map4 = new HashMap<String, String>();
        Map<String, String> map5 = new HashMap<String, String>();
        
        map1.put("Seller11", "10/10/2020");
        map1.put("Seller12", "11/11/2020");
        map1.put("Seller13", "12/12/2020");
        
        map2.put("Seller21", "10/10/2020");
        map2.put("Seller22", "11/11/2020");
        map2.put("Seller23", "12/12/2020");
        
        map3.put("Seller31", "10/10/2020");
        map3.put("Seller32", "11/11/2020");
        map3.put("Seller33", "12/12/2020");
        
        map4.put("Seller41", "10/10/2020");
        map4.put("Seller42", "11/11/2020");
        map4.put("Seller43", "12/12/2020");
        
        map5.put("Seller51", "10/10/2020");
        map5.put("Seller52", "11/11/2020");
        map5.put("Seller53", "12/12/2020");        
        
        BookDetails bd1 = new BookDetails(p1, map1);
        BookDetails bd2 = new BookDetails(p2, map2);
        BookDetails bd3 = new BookDetails(p3, map3);
        BookDetails bd4 = new BookDetails(p4, map4);
        BookDetails bd5 = new BookDetails(p5, map5);
        
        Book b1 = new Book(1, "Book1", "Author1", "1991", bd1);
        Book b2 = new Book(2, "Book2", "Author2", "1992", bd2);
        Book b3 = new Book(3, "Book3", "Author3", "1993", bd3);
        Book b4 = new Book(4, "Book4", "Author4", "1994", bd4);
        Book b5 = new Book(5, "Book5", "Author5", "1995", bd5);
        books.put(1, b1);
        books.put(2, b2);
        books.put(3, b3);
        books.put(4, b4);
        books.put(5, b5);
        
    }

    @Override
    public String getBookDetails(int bookId) {
        return books.get(bookId).getBookDetails().toString();
    }

}
