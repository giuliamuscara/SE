package soap.server;

import java.util.Map;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BookDetails {
    private float price;
    private Map<String, String> sellers;
    
    public BookDetails(){}
    
    public BookDetails(float p, Map<String, String> s){
        this.price = p;
        this.sellers = s;
    }
    
    public float getPrice(){
        return this.price;
    }
    
    public void setPrice(float p){
        this.price = p;
    }
    
    public Map<String, String> getSellers(){
        return this.sellers;
    }
    
    public void setSellers(Map<String, String> s){
        this.sellers = s;
    }
    
    @Override
    public String toString(){
        String toPrint = "";
        for (String name: sellers.keySet()){
            String key = name;
            String value = sellers.get(name);
            toPrint = toPrint + " " + key + " " + value;
        } 
        return String.valueOf(this.price) + " " + toPrint;
    }
}
