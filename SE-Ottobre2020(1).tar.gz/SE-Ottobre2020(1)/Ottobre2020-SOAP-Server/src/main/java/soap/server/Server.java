
package soap.server;

import javax.xml.ws.Endpoint;

public class Server {
    public static void main(String args[]) throws InterruptedException {
        WSImpl implementor = new WSImpl();
        String address = "http://localhost:7777/WSInterface";
        Endpoint.publish(address, implementor);
        while(true) {}
    }
}
