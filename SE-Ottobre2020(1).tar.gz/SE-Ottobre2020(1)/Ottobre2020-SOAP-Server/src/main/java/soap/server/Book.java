package soap.server;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Book {

    private String title;
    private String author;
    private String year;
    private int id;
    private BookDetails bd;
    
    public Book(){}
    
    public Book(int id, String title, String author, String year, BookDetails bd){
        this.id = id;
        this.title = title;
        this.author = author;
        this.year = year;
        this.bd = bd;
    }
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public BookDetails getBookDetails(){
        return this.bd;
    }
    
    public void setBookDetails(BookDetails bd){
        this.bd = bd;
    }
    
    @Override
    public String toString(){
        return "Book: " + String.valueOf(this.id) + " " + this.title + " " + this.author + " " + this.year;
    }
}
