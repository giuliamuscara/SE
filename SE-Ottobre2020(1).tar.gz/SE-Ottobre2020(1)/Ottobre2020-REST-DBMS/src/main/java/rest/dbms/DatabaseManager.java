package rest.dbms;

import java.sql.*;

public class DatabaseManager {

    public static void main(String[] args) throws Exception {

        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:"+args[0]);
        Statement stat = conn.createStatement();

        if (args[1].equals("create")) {
            stat.executeUpdate("drop table if exists books;");
            stat.executeUpdate("create table books (id, title, author, year);");
            PreparedStatement prep = conn.prepareStatement("insert into books values (?, ?, ?, ?);");
            prep.setString(1, "1");
            prep.setString(2, "Book1");
            prep.setString(3, "Author1");
            prep.setString(4, "1991");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "2");
            prep.setString(2, "Book2");
            prep.setString(3, "Author2");
            prep.setString(4, "1992");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "3");
            prep.setString(2, "Book3");
            prep.setString(3, "Author3");
            prep.setString(4, "1993");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "4");
            prep.setString(2, "Book4");
            prep.setString(3, "Author4");
            prep.setString(4, "1994");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            prep.setString(1, "5");
            prep.setString(2, "Book5");
            prep.setString(3, "Author5");
            prep.setString(4, "1995");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            
        } else {
            ResultSet rs = stat.executeQuery("select * from books;");
            while (rs.next()) {
                System.out.println("Book: " + rs.getString("id") + " " + rs.getString("title") + " " + 
                        rs.getString("author") + " " + rs.getString("year"));
            }
            rs.close();
        }
        conn.close();
    }
}
