/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.rest_server_july2020;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author studente
 */
@XmlRootElement(name = "ListMovies")
public class ListMovies {
    int[] l;
    
    public ListMovies() {}
    
    public ListMovies(int[] l) {
    this.l = l;
    }
    
    public int[] getList() { return l;}
    public void setList(int[] l) { this.l = l; }
    
}
