/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.rest_server_july2020;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author studente
 */
@XmlRootElement(name = "Movie")
public class Movie {
    String title;
    String director;
    String year;
    int id;
    
    public Movie(String title, String d, String y, int i) {
        this.title = title;
        this.director = d;
        this.year = y;
        this.id = i;
    }
    
    public Movie() {}
    
    
    public void setTitle(String t) { title = t;}
    public void setDirector(String t) { director = t;}
    public void setYear(String t) { year = t;}
    public void setID(int t) { id = t;}
    
    public String getTitle() { return title; }
    public String getDirector() { return director; }
    public String getYear() { return year; }
    public int getID() { return id; }
}
