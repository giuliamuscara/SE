/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.rest_client_july2020;


import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import javax.xml.bind.JAXB;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

/**
 *
 * @author studente
 */
public class Client {
    private static final String BASE_URL = "http://localhost:8080/movies/";
    private static CloseableHttpClient client;

    public static void main(String[] args) throws IOException{
        client = HttpClients.createDefault();
       
        Movie m = getMovie(5);
        System.out.println(m.getTitle());
        ListMovies lis = getAllMovies();
        int[] tutti = lis.getList();
        if (tutti != null) {
            for (int i=0; i < tutti.length; i++) {
                int id = tutti[i];
                Movie film = getMovie(id);
                System.out.println("Movie "+ id + " is: "+film.getTitle()+ " in "+film.getYear());
            }
        }
    }
    
    
     private static Movie getMovie(int id) throws IOException {
        final URL url = new URL(BASE_URL + id);
        final InputStream input = url.openStream();
        return JAXB.unmarshal(new InputStreamReader(input), Movie.class);
    }

      private static ListMovies getAllMovies() throws IOException {
        final URL url = new URL(BASE_URL);
        final InputStream input = url.openStream();
        return JAXB.unmarshal(new InputStreamReader(input), ListMovies.class);
        }
        
 }

