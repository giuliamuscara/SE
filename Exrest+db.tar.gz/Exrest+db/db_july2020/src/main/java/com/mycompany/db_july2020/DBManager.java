/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.db_july2020;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author studente
 */
public class DBManager {
    public static void main(String[] args) throws Exception {
        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:"+args[0]);
        Statement stat = conn.createStatement();
        if (args[1].equals("create")) {
            stat.executeUpdate("drop table if exists movies;");
            stat.executeUpdate("create table movies (ID, title, year, directorID);");
            PreparedStatement prep = conn.prepareStatement("insert into movies values (?, ?, ?, ?);");
            
            stat.executeUpdate("drop table if exists directors;");
            stat.executeUpdate("create table directors (ID, name, yearOfBirth);");
            PreparedStatement prep2 = conn.prepareStatement("insert into directors values (?, ?, ?);");
            
            prep2.setString(1, "1");
            prep2.setString(2, "James Franco");
            prep2.setString(3, "1997");
            prep2.addBatch();
            conn.setAutoCommit(false);
            prep2.executeBatch();
            conn.setAutoCommit(true);
            
            prep2.setString(1, "2");
            prep2.setString(2, "GIulia Muscara");
            prep2.setString(3, "1998");
            prep2.addBatch();
            conn.setAutoCommit(false);
            prep2.executeBatch();
            conn.setAutoCommit(true);
            
            prep2.setString(1, "3");
            prep2.setString(2, "Paola Roma");
            prep2.setString(3, "1997");
            prep2.addBatch();
            conn.setAutoCommit(false);
            prep2.executeBatch();
            conn.setAutoCommit(true);
            
            prep2.setString(1, "4");
            prep2.setString(2, "Maria Rossi");
            prep2.setString(3, "1997");
            prep2.addBatch();
            conn.setAutoCommit(false);
            prep2.executeBatch();
            conn.setAutoCommit(true);
            
            prep2.setString(1, "5");
            prep2.setString(2, "Savino");
            prep2.setString(3, "1940");
            prep2.addBatch();
            conn.setAutoCommit(false);
            prep2.executeBatch();
            conn.setAutoCommit(true);
            
            prep2.setString(1, "6");
            prep2.setString(2, "Sophia Coppola");
            prep2.setString(3, "1980");
            prep2.addBatch();
            conn.setAutoCommit(false);
            prep2.executeBatch();
            conn.setAutoCommit(true);
            
            prep2.setString(1, "7");
            prep2.setString(2, "Tarantino");
            prep2.setString(3, "1960");
            prep2.addBatch();
            conn.setAutoCommit(false);
            prep2.executeBatch();
            conn.setAutoCommit(true);
            
           
            
            prep.setInt(1, 1);
            prep.setString(2, "Titanic");
            prep.setString(3, "1997");
            prep.setString(4, "1");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            
            
            prep.setInt(1, 2);
            prep.setString(2, "Mean girls");
            prep.setString(3, "2002");
            prep.setString(4, "5");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 3);
            prep.setString(2, "Schindlerslist");
            prep.setString(3, "1997");
            prep.setString(4, "1");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 4);
            prep.setString(2, "American beauty");
            prep.setString(3, "1995");
            prep.setString(4, "2");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 5);
            prep.setString(2, "Happy days");
            prep.setString(3, "2000");
            prep.setString(4, "3");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 6);
            prep.setString(2, "Apocalypse");
            prep.setString(3, "2010");
            prep.setString(4, "4");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 7);
            prep.setString(2, "Forrest Gump");
            prep.setString(3, "1996");
            prep.setString(4, "6");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 8);
            prep.setString(2, "Matrix");
            prep.setString(3, "1990");
            prep.setString(4, "7");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 9);
            prep.setString(2, "Beautiful");
            prep.setString(3, "2015");
            prep.setString(4, "5");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 10);
            prep.setString(2, "Ocean eleven");
            prep.setString(3, "2001");
            prep.setString(4, "5");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 11);
            prep.setString(2, "007");
            prep.setString(3, "1998");
            prep.setString(4, "2");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 12);
            prep.setString(2, "La fabbrica di cioccolato");
            prep.setString(3, "2004");
            prep.setString(4, "7");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 13);
            prep.setString(2, "Streghe");
            prep.setString(3, "2019");
            prep.setString(4, "7");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 14);
            prep.setString(2, "Che bella giornata");
            prep.setString(3, "2017");
            prep.setString(4, "1");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
            prep.setInt(1, 15);
            prep.setString(2, "Cado dalle nubi");
            prep.setString(3, "2014");
            prep.setString(4, "1");
            prep.addBatch();
            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.setAutoCommit(true);
        } 
        else {
            ResultSet rs = stat.executeQuery("select * from movies;");
            while (rs.next()) {
                System.out.print("Movie = " + rs.getString("ID") + " is : ");
                System.out.println(rs.getString("title"));
            }
            ResultSet rsdir = stat.executeQuery("select * from directors;");
            while (rsdir.next()) {
                System.out.print("Director = " + rsdir.getString("ID") + " is : ");
                System.out.println(rsdir.getString("name"));
            }
            rs.close();
        }
        conn.close();
    }
}
