/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.rest_server_july2020;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

/**
 *
 * @author studente
 */
@Path("/movies")
@Produces("text/xml")
public class MoviesRepository {
    List<Movie> m = new ArrayList<>();
    private Connection conn;
    
     public void setConnection(String pos) {
        try {
            try {
                Class.forName("org.sqlite.JDBC");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
            }
            conn = DriverManager.getConnection("jdbc:sqlite:"+pos);
            System.out.println("Connesso al db!");
        } catch (SQLException ex) {
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
    
    @GET
    @Path("{movieId}")
    public Movie getMovie(@PathParam("movieId") int movieId) {
        PreparedStatement stat = null;
        Movie movie = null;
        System.out.println("In getmovie...");
        try {
            stat = conn.prepareStatement("select * from movies where id = ?");
            stat.setInt(1, movieId);
        
        ResultSet rs = stat.executeQuery();
        System.out.println("Query executed...");
        if (rs == null) { System.out.println("result of query null");}
        if (rs.next()) {
            movie = new Movie();
            movie.setID(movieId);
            movie.setTitle(rs.getString("title"));   
           
            movie.setYear(rs.getString("year"));
         
            movie.setDirector(rs.getString("directorID"));
          
              
            return movie;
           // Logger.getLogger(MoviesRepository.class.getName()).log(Level.INFO, "Accessed : " + movie.getTitle());
            
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
        return movie;
        
    }
    
    @GET
    @Path("")
    public ListMovies getAllMovies() {
        int[] l = new int[15];
        PreparedStatement stat = null;
        int count = 0;
        int id = 0;
        try {
            stat = conn.prepareStatement("select * from movies");
          
        ResultSet rs = stat.executeQuery();
        
        while (rs.next()) {
            
            id = (rs.getInt("ID"));
            l[count] = id;
            count = count +1;
           // Logger.getLogger(MoviesRepository.class.getName()).log(Level.INFO, "Accessed : " + id);
            
        }
        rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(MoviesRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new ListMovies(l);
    }

   
        
}
