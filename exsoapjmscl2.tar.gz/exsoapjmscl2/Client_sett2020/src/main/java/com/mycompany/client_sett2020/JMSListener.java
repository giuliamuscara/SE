/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.client_sett2020;

import com.mycompany.soapserver_sett2020.Professor;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;




/**
 *
 * @author studente
 */
public class JMSListener implements MessageListener {
    private TopicConnection topicConnection;
    private TopicSession topicSession = null;
    private Destination destination = null;
    private MessageProducer producer = null;
   

    public JMSListener() {
        
        Context jndiContext = null;
                ConnectionFactory topicConnectionFactory = null;
                
                String destinationName = "dynamicTopics/professors";
                
		try {
			
                    Properties props = new Properties();
        
                    props.setProperty(Context.INITIAL_CONTEXT_FACTORY,"org.apache.activemq.jndi.ActiveMQInitialContextFactory");
                    props.setProperty(Context.PROVIDER_URL,"tcp://localhost:61616");
                    jndiContext = new InitialContext(props);   
                    
                    
                    		
			
                    topicConnectionFactory = (ConnectionFactory)jndiContext.lookup("ConnectionFactory");
                    destination = (Destination)jndiContext.lookup(destinationName);
                    topicConnection = (TopicConnection)topicConnectionFactory.createConnection();
                    topicSession = (TopicSession)topicConnection.createSession(false, Session.AUTO_ACKNOWLEDGE);

                    TopicSubscriber topicSubscriber =  
                            topicSession.createSubscriber((Topic)destination);
			
                    topicSubscriber.setMessageListener(this);
		} catch (JMSException err) {
			err.printStackTrace();
		} catch (NamingException err) {
			err.printStackTrace();
                }
    }
    
    public void stop() {
		try {
			topicConnection.stop();
		} catch (JMSException err) {
			err.printStackTrace();
		}
	}
    
    public void start() {
		try {
			topicConnection.start();
		} catch (JMSException err) {
			err.printStackTrace();
		}
	}
    
    public void onMessage(Message mex) {
        int count = 0;
            try {
                    String id = mex.getStringProperty("ID");
                    count = count +1;
                    Professor p = getDetails(id);  
                    System.out.println("Item "+count+">> "+ " Professor with id "+id);
                    System.out.println("Professor with id "+id+ " has details "+p.getName()+ " "+ p.getSurname()+ ", "+p.getCourse() );
		} catch (JMSException err) {
			err.printStackTrace();
		}
    }
    
    private static Professor getDetails(String id) {
        
        com.mycompany.soapserver_sett2020.WSImplService service = new com.mycompany.soapserver_sett2020.WSImplService();
        com.mycompany.soapserver_sett2020.WSInterface port = service.getWSImplPort();
        // TODO initialize WS operation arguments here
        java.lang.String arg0 = id;
        // TODO process result her
        
        return port.getDetails(arg0);

    }
    
}
