/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.soapserver_sett2020;
import java.util.*;
import javax.jws.WebService;

/**
 *
 * @author studente
 */
@WebService(endpointInterface = "com.mycompany.soapserver_sett2020.WSInterface")
public class WSImpl implements WSInterface {
    List<Professor> p = new ArrayList<>();
    
    {
    Professor p1 = new Professor("Massimo", "Mecella", "SE", "1");
    Professor p2 = new Professor("Maurizio", "Lenzerini", "DM", "2");
    Professor p3 = new Professor("Fabrizio", "D'amore", "CNS", "3");
    Professor p4 = new Professor("Silvia", "Bonomi", "SG", "4");
    Professor p5 = new Professor("Francesca", "Cuomo", "NI", "5");
    Professor p6 = new Professor("Riccardo", "Rosati", "KRST", "6");
    Professor p7 = new Professor("Lavinia", "Amoroso", "RO", "7");
    p.add(p1);
    p.add(p2);
    p.add(p3);
    p.add(p4);
    p.add(p5);
    p.add(p6);
    p.add(p7);
    }
    
    @Override
    public Professor getDetails(String id) {
        for (int i=0; i < p.size() ; i++) {
            Professor prof = p.get(i);
            if ((prof.getID()).equals(id)) { return prof; }
        }
        return null;
    }
}
