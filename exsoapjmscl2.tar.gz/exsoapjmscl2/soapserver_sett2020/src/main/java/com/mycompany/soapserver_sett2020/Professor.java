/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.soapserver_sett2020;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author studente
 */
@XmlRootElement
public class Professor {
    String name;
    String surname;
    String course;
    String id;
    
    public Professor() {}
    
    public Professor(String n, String s, String c, String i) {
        this.name = n;
        this.surname = s;
        this.course = c;
        this.id = i;
    }
    
    public void setName(String n) { name = n; }
    public void setID(String n) { id = n; }
    public void setSurname(String n) { surname = n; }
    public void setCourse(String n) { course = n; }
    public String getName() { return name; }
    public String getSurname() { return surname; }
    public String getCourse() { return course; }
    public String getID() { return id; }
}
